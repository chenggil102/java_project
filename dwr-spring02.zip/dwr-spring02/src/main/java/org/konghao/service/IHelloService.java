package org.konghao.service;

public interface IHelloService {
	public String say(String name);
	
	public User load();
}
