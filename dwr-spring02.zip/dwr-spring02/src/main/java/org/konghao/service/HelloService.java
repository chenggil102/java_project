package org.konghao.service;

import org.apache.log4j.Logger;
import org.mortbay.log.Log;



public class HelloService implements IHelloService {
	Logger log = Logger.getLogger(HelloService.class);
	public String say(String name) {
		return "hello:"+name;
	}

	@Override
	public User load() {
		log.info("##########stat#########");
		log.info("dddddddddddddddddddddd");
		log.info("##########end#########");
		return new User(1,"abc");
	}

}
